#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  1 20:39:16 2018

@author: wu
"""
import re
import pandas as pd
i=0
listModel = []
with open('data.txt','r') as f:
    read_line = f.readlines()
    for item in read_line:
        i += 1
        item = item.replace('\n','')
        item = item.replace('\r','')
        

        dictMoel={}
        models = [r'model.*(?=detaUrl)', r'price.*(?=mileage)', r'mileage.*(?=detalUrl)', r'detalUrl.*(?=carDJ)',r'carDJ.*(?=city)',r'city.*']
        for model in models:
            line = re.search(model,item).group(0)
            line = line.strip()
            lines = line.split('=')
            lines[0]=lines[0].strip()
            lines[1]=lines[1].strip()
            try:
                dictMoel[lines[0]] = lines[1].replace('\n','')
            except Exception as e:
                print('error = %s' % (e))
                print('filePath= %s' % (lines))

              

        listModel.append(dictMoel)
pddata = pd.DataFrame(listModel)
pddata.to_csv("output-data/che300_data.csv", index=False)
pip install lxml
pip install selenium=3.0.1

车300估价接口需要提取图片中的文字，需要安装下面的两个包
pip install pytesseract
pip install Pillow

 还需要在自己的电脑上安装phantomjs，只需要下载下来，把phantomjs/bin/phantomjs加入全局变量即可

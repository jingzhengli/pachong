from urllib import request
import json, random
from lib.grabHtmlAbc import GetHtml as AbcGetHtml

class GetHtml(AbcGetHtml):
    timeout=10

    def __init__(self, headers = {}):
        self.headers = headers
        AbcGetHtml.__init__(self)

    def getHtml(self, url):
        self.headers['User-Agent'] = self.getUserAgent()
        html=''
        req = request.Request(url, headers = self.headers)
        try:
            resp = request.urlopen(req, timeout = self.timeout)
            code = resp.getcode()
            if code==200:
                html=resp.read()
        except Exception as e:
            print("request error: url=%s" % (url))
            print(e)
        return html
        
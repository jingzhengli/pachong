#-*- coding: UTF-8 -*-
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.proxy import ProxyType 
from lib.grabHtmlAbc import GetHtml as AbcGetHtml
import random, time
from lib.ipProxy import IpProxy

class GetHtml(AbcGetHtml):

    def __init__(self, driver=0, headers = {}, proxy = True):
        self.headers = headers
        AbcGetHtml.__init__(self)
        self.driver = self._init_driver(driver, proxy)

    def _init_driver(self, driver, proxy):
        if driver == 1:
            return self._chrome_webdriver()
        if driver == 2:
            return self._safari_webdriver()

        return self._phantomjs_webdriver(proxy)

    def _phantomjs_webdriver(self, proxy = True, timeout = 20):
        dcap = DesiredCapabilities.PHANTOMJS.copy() #dict(DesiredCapabilities.PHANTOMJS)
        dcap["phantomjs.page.settings.loadImages"] = False 

        for (k, v) in self.headers.items():
            dcap['phantomjs.page.customHeaders.{}'.format(k)] = v

        dcap["phantomjs.page.settings.userAgent"] = self.getUserAgent()

        if proxy == True:
            ipPy = IpProxy()
            ips = ipPy.getIps()
            if len(ips) > 0:

                proxyIp = random.choice(ips)
                print('代理IP:%s'% (proxyIp))
                proxy = webdriver.Proxy()
                proxy.proxy_type = ProxyType.MANUAL
                proxy.http_proxy = proxyIp
                proxy.add_to_capabilities(dcap)

        wd = webdriver.PhantomJS(desired_capabilities=dcap)
        wd.set_page_load_timeout(timeout)
        return wd

    def _chrome_webdriver(self):
        options = webdriver.ChromeOptions()
        for (k, v) in self.headers.items():
            options.add_argument('%s="%s"' % (k, v))
        options.add_argument('--headless') 
        options.add_argument('--disable-gpu')
        options.add_argument('user-agent="%s"' % (self.getUserAgent))
        return webdriver.Chrome(chrome_options=options)

    def _safari_webdriver(self):
        return webdriver.Safari()

    def get_html(self, url):
        self.driver.get(url)
        return self.driver.page_source

    def getHtml(self, url, sleepTime = 0):
        #self.driver.implicitly_wait(10)
        self.driver.get(url)
        if sleepTime > 0:
            time.sleep(sleepTime)
        html = self.driver.page_source
        return html

    def clear(self):
        self.driver.close()
        self.driver.quit()
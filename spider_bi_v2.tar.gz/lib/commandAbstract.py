#-*-coding:utf-8-*-

import abc

class CommandAbstract(object):
    arguments = {}
    argumentsValue = {}
    def __init__(self):
        self.arguments = {}
        self.argumentsValue = {}
        self.configure()

    @abc.abstractmethod
    def configure(self):pass

    @abc.abstractmethod
    def run(self):pass

    def setArguments(self, key, description):
        self.arguments[key] = description
        return self

    def setArgumentsValue(self, key, value):
        self.argumentsValue[key] = value
        return self

    def getArguments(self, key):
        if key in self.argumentsValue:
            return self.argumentsValue[key]
        return ''
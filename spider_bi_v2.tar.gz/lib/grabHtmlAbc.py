#-*- coding: UTF-8 -*-
import sys
import random

class GetHtml(object):

    def __init__(self):
        self.userAgentFile = 'resources/ua_list_pc.txt'

    def start(self):
        pass

    def clear(self):
        pass

    def getUserAgent(self):
        return random.choice(self.loadUserAgent())

    def get_html(self, url):
        pass

    def save_html(self, save_file, html_src):
        # if sys.version_info.major == 2:
        #     html_src = html_src.encode('utf8', 'ignore')
        try:
            html_src = html_src.encode('utf8', 'ignore')
        except UnicodeError:
            # html_src = html_src.encode('ascii', 'ignore')
            pass

        with open(save_file, 'w') as ff:
            ff.write(html_src)
            ff.close()

    def loadUserAgent(self):
        f = open(self.userAgentFile, 'r')
        lines = f.readlines()
        f.close()
        userAgentList = []
        for line in lines:
            userAgentList.append(line.strip())
        return userAgentList
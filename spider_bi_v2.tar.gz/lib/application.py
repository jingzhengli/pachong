#-*-coding:utf-8-*-

import os
import re
import warnings
class Application():
    obj = None
    def __init__(self, argvs):
        self.argvs = argvs
        self.getObj()

    def run(self):
        if len(self.argvs) == 1:
            return
        if self.obj == None:
            print('select a command')
            return
        count = 0
        if len(self.obj.arguments) > 0:
            for k,argv in enumerate(self.argvs):
                if k < 2:
                    continue
                arr = argv.split("=",1)
                if len(arr) == 2 and arr[0] in self.obj.arguments:
                    count += 1
                    self.obj.setArgumentsValue(arr[0], arr[1])
            if count != len(self.obj.arguments):
                print("是否缺少以下参数:")
                for i,j in self.obj.arguments.items():
                    space = self.getSpace(i)
                    print("%s%s%s"%(i,space,j))
                return
        if len(self.argvs) > 2 and len(self.obj.arguments) == 0:
            print("是否是 \"%s %s\" command"%(self.argvs[0],self.argvs[1]))
            return
        warnings.filterwarnings('ignore')
        self.obj.run()

    def getObj(self):
        reg = r'^class *([a-zA-Z0-9]+)[(\?]?'
        filelist = os.listdir('command')
        for index,file in enumerate(filelist):
            if(file == '__init__.py'):
                continue
            if os.path.isfile('command/'+file) == False:
                continue
            f = open('command/'+file,'r', encoding = 'utf-8')
            lines = f.readlines()
            f.close()
            mch = None
            for line in lines:
                mch = re.match(reg,line)
                if mch != None:
                    break;
            if mch != None:
                strmodel = mch.groups()[0]
                model = __import__('command.'+file.replace('.py',''), fromlist=True)
                obj = getattr(model, strmodel)()
                if len(self.argvs) == 1:
                    space = self.getSpace(obj.name)
                    print(obj.name + space + obj.description)
                else:
                    if obj.name == self.argvs[1]:
                        self.obj = obj
                        break
    def getSpace(self, title):
        length = len(title)
        i = 50 - length
        space = ''
        while i > 0:
            space += ' '
            i -= 1
        return space
from lib.getHtmlByUrlib import GetHtml
import time,os,json

class IpProxy:

    def __init__(self):
        self.orderNo = 'd309b3523c143c9670330098585b5eb5'
        self.ipFlagPath = 'output-data/ipFlag.txt'

    def getIps(self):
        nowTime = time.strftime("%Y%m%d%H%M", time.localtime())
        nowTime = str(nowTime)
        ips = []

        if os.path.exists(self.ipFlagPath) == False:
            ips = self.getIpsFromUrl()
            if len(ips) > 0:
                with open(self.ipFlagPath, 'w') as f:
                    txt = {"time":nowTime, "ips": ips}
                    f.write(json.dumps(txt))
        else:
            with open(self.ipFlagPath, 'r') as f:
                ipsInfo = f.read()
                try:
                    ipsInfo = json.loads(ipsInfo)
                    if 'time' in ipsInfo.keys() and ipsInfo['time'] == nowTime:
                        ips = ipsInfo['ips']
                    else:
                        ips = self.getIpsFromUrl()
                        if len(ips) > 0:
                            with open(self.ipFlagPath, 'w') as f:
                                txt = {"time":nowTime, "ips": ips}
                                f.write(json.dumps(txt))
                except Exception as e:
                    print(e)
                    ips = self.getIpsFromUrl()
                    if len(ips) > 0:
                        with open(self.ipFlagPath, 'w') as f:
                            txt = {"time":nowTime, "ips": ips}
                            f.write(json.dumps(txt))
        return ips

    def getIpsFromUrl(self):
        apiUrl = "http://api.ip.data5u.com/dynamic/get.html?order=%s" % (self.orderNo)
        sc = GetHtml()
        res = sc.getHtml(apiUrl)
        ips = []
        if res != '':
            resIp = res.decode()
            resIp = resIp.strip("\n")
            ips = resIp.split("\n")
            if 'success' in ips[0]:
                return []
        return ips
#-*-coding:utf-8-*-
import pandas as pd
import time
class Business(object):

    def find_exist(self,city,year,mileage,url,headlen,price,guazi_data):
        isExist = False
        
        exist_price = 0
        select_data = guazi_data[guazi_data['city']==city ]
        select_data = select_data[select_data['carDj']==year]
        select_data = select_data[select_data['mileage'] == mileage]
        #city_group= guazi_data.groupby(['carDj','city'])
        #city_dict=dict(list(city_group))
        #car_group = city_dict.get((year,city),[])
        line_index =list(select_data.index)
        car_len = len(select_data)
        if(car_len == 0):
            return False
        url = url[headlen:]
        url = url.split('#')[0] 
        #car_group.index=range(car_len)
        for i in range(car_len):
            save_url=select_data.iloc[i,2][headlen:] # detail_url
            save_url=save_url.split('#')[0]
           
            if(save_url == url):
                isExist = True
                exist_price = select_data.iloc[i,5]#price
                if(abs(float(str(exist_price)) -float(price))>0.001):
                    if(pd.isnull(select_data.iloc[i,7])):
                        if(pd.isnull(select_data.iloc[i,6])):
                            price_list = str(exist_price) +':NULL,'+str(price)+':'+ time.strftime("%y/%m/%d/%H")
                        else:
                            price_list = str(exist_price) +':'+str(select_data.iloc[i,6]) +',' +str(price)+':'+ time.strftime("%y/%m/%d/%H")
                    else:    
                        price_list = select_data.iloc[i,7]+','+str(price)+':'+ time.strftime("%y/%m/%d/%H") 
                    new_date = time.strftime("%y/%m/%d/%H")
                    guazi_data.ix[line_index[i],'update_date'] = new_date
                    guazi_data.ix[line_index[i],'price_list'] = price_list
                    #insert into ori csv
                    break
           
        return  isExist
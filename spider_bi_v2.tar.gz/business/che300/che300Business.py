#-*-coding:utf-8-*-
import re
import time
from business.business import Business
import lxml.html as HTML

import os, sys, base64, random, time, json
import lxml.etree as etree
from PIL import Image
import pytesseract
import pandas as pd


class Che300Business(Business):

    def __init__(self):
        self.host = 'www.che300.com'


    def parsePredictPrice(self, root):
        lowestPrice =''
        predictPrice =''
        # '//div[@class="detail"]/div[@class="detail-wrap"]/div[@class="dt-info"]
        modelClass = '//div[@class="dti-wrap clearfix"]/div[@class="dti-right"]/div[@class="dtir-cp"]' 
        liElement = root.xpath(modelClass)
        if(len(liElement) != 0):
             modelClass = 'p/span[@id="lowestNewPrice"]' 
             lowestPriceElement = liElement[0].xpath(modelClass)
             if(len(lowestPriceElement)!=0):
                 lowestPrice = lowestPriceElement[0].text
                 
             modelClass = 'p' 
             lowestPriceElement = liElement[0].xpath(modelClass)
             if(len(lowestPriceElement) >=2):
                 predictPrice = lowestPriceElement[1].text
        return (lowestPrice,predictPrice)         
    #获取车辆列表信息
    def parseModelInfo(self, root, self_data,dict_price):
        listModel = []
        changeUrl = False
         
        
        try:
            modelClass = '//div[@class="list"]/div[@class="list-wrap"]/ul[@class="list-row clearfix"]'
            liElement = root.xpath(modelClass)
            if (len(liElement)!= 0):
                for row in liElement:
                    rowElement = row.xpath('li[@class="list-item"]')
                    for singleElement in rowElement:
                        info = singleElement.xpath('div[@class="list-info"]')
                        model = info[0].find('a').find('p').text
                        detailUrl = info[0].find('a').get('href')
                        source = info[0].xpath('p/a[@style]')[0].text
                        source ='che300_'+str(source)
                        ymList = info[0].xpath('p/a[@id]')[0].text
                        
                        ymList = ymList.split('/')
                        year = ymList[0].replace(' ','')
                        
                        mileage = ymList[1]
                        mileage = re.search(r'\d+(\.\d+)?',mileage).group(0)
                        city = ymList[2].replace(' ','')
                        
                        price = info[0].xpath("p[@class='clearfix']/span[@class='list-price']/i")[0].text
                        price = re.search(r'\d+(\.\d+)?',price).group(0)
                        price_his =''
                        (isExist,price_his) = self.find_exist(city,year,mileage,detailUrl,price,self_data,dict_price)
                        if(isExist==True and price_his == ''):
                            #escapeCnt = escapeCnt+1
                            #print('escapeCnt',escapeCnt)
                            continue
                        dict_price[detailUrl]=price
                        new_date = time.strftime("%y/%m/%d")
                        listModel.append({'model': model, 'carDj': year, 'mileage': mileage, 'city':city, 'price':price, 'source':source,'price_his':price_his,
                                          'detailUrl': detailUrl ,'update_date':new_date})
            else:
                modelClass = '//div[@class="mainCon"]/a[@class="carItem"]'
                liElement = root.xpath(modelClass) 
                for aElement in liElement:
                    element = aElement.xpath('div[@class="carItemImg"]')
                    detailUrl = aElement.get('href')
                    info = element[0].xpath('div[@class="carItemMsgTitle"]')
                    model = info[0].find('span').text
                    info = element[0].xpath('div[@class="carItemCon"]/div[@class="carItemMsgMile"]')
                    ymList = info[0].find('span').text
                    ymList = ymList.split('上牌')
                    year = ymList[0].strip()
                    source ='che300_'
                    ymList = ymList[1].split('-')
                    while '' in ymList:
                        ymList.remove('')
                    mileage = ymList[0]    
                    mileage = re.search(r'\d+(\.\d+)?',mileage).group(0)
                    city = ymList[1].strip()
                    
                    price = element[0].xpath('div[@class="carItemCon"]/div[@class="pt"]/p[@class="pt_p"]')[0].text
                    price = re.search(r'\d+(\.\d+)?',price).group(0)
                    (isExist,price_his) = self.find_exist(city,year,mileage,detailUrl,price,self_data,dict_price)
                    changeUrl = True
                    if(isExist==True and price_his == ''):
                        #escapeCnt = escapeCnt+1
                        #print('escapeCnt',escapeCnt)
                        continue
                    dict_price[detailUrl]=price
                    new_date = time.strftime("%y/%m/%d")                    
                    listModel.append({'model': model, 'carDj': year, 'mileage': mileage, 'city':city, 'price':price,  'source':source,'price_his':price_his,
                                          'detailUrl': detailUrl ,'update_date':new_date})                    
                     
        except Exception as e:
            print(e)
        return (listModel,changeUrl)

    #解析分页的url
    def pageHref(self, root, url = ''):
        if(url != ''):
            page = re.search(r'p=\d*',url).group(0)
            if(len(page)>2):
                page = int(page[2:])+20
            else:
                page = 20
            page = 'p='+str(page)
            pageUrl = re.sub(r'p=\d*',page,url)
            return pageUrl
        pageClass = '//div[@class="list"]/div[@class="pagination"]/ul[@class="page_index"]/li/a'
        nextEmlemnt = root.xpath(pageClass)
        if len(nextEmlemnt) == 0:
            return ''
        txt = nextEmlemnt[-1].text
        if txt.find('下一页')>-1:
            pageUrl = nextEmlemnt[-1].get('href')
        else:
            return ''
        return pageUrl
    
    
    def getPrice(self, html, fileName):
        root = HTML.fromstring(html)
        dictRule = {
            'excellent': '//div[@id="excellent"]/div/ul[@class="sp-value clearfix"]/li/span/img/@src',
            'good': '//div[@id="good"]/div/ul[@class="sp-value clearfix"]/li/span/img/@src',
            'common': '//div[@id="common"]/div/ul[@class="sp-value clearfix"]/li/span/img/@src'
        }

        res = {}
        for k, rule in dictRule.items():
            listResult = root.xpath(rule)
            if len(listResult) == 0:
                print('fileName [%s] error' % (fileName))
                return {}
            print(rule)
            listPrice = []
            print('----------%s begin--------' % (k))
            for result in listResult:
                arr = result.split(',')
                img = arr[1]
                imgData = base64.b64decode(img)
                imgName = 'output-data/che300/%s.png' % (fileName)
                with open(imgName, 'wb') as f:
                    f.write(imgData)
                code = pytesseract.image_to_string(Image.open(imgName))
                listPrice.append(code)
                os.remove(imgName)
                print(code)
            res[k] = listPrice
            print('----------%s end--------' % (k))
        print(res)    
        return res 
    
    def find_exist(self,city,year,mileage,url,price,self_data,dict_price):
        isExist = False
        
        save_price = dict_price.get(url,0) 
        price_his =''
        if(save_price == 0):
            return (False,price_his)
        #select_data = self_data[self_data['detalUrl'].str.strip() ==url.strip() ]
        #car_len = len(select_data)
        #if(car_len == 0):
            #return False
        #if(select_data.iloc[0,0] != year or select_data.iloc[0,3] != mileage):
            #return  isExist
        #line_index =list(select_data.index)
        print('the car is exist',url)
        
        isExist = True
        save_price = re.search(r'\d+(\.\d+)?',save_price).group(0)
        if(abs(float(str(save_price)) -float(price))>0.001):
            print('the price is diff,old',save_price,'new price',price)
            select_data = self_data[self_data['detailUrl'] ==url]
            #line_index =list(select_data.index)
            if(pd.isnull(select_data['price_his'].iloc[0])):
                if(pd.isnull(select_data['update_date'].iloc[0])):
                    price_his = str(save_price) +':NULL,'+str(price)+':'+ time.strftime("%y/%m/%d")
                else:
                    price_his = str(save_price) +':'+str(select_data['update_date'].iloc[0]) +',' +str(price)+':'+ time.strftime("%y/%m/%d")
            else:    
                price_his = select_data['price_his'].iloc[0]+','+str(price)+':'+ time.strftime("%y/%m/%d") 
            #new_date = time.strftime("%y/%m/%d/%H")
            #self_data.ix[line_index[0],'update_date'] = new_date
            #self_data.ix[line_index[0],'price_his'] = price_his
                    #insert into ori csv
                    
           
        return  (isExist, price_his)   
    
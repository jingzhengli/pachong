#-*-coding:utf-8-*-
import time
class Che168Business(object):

    def __init__(self):
        self.host = 'www.che168.com'

    #获取车辆列表信息
    def parseHtml(self, root, brandDirPath):
        listModel = []
        listClass = '//div[@class="list-photo"]/ul[@class="fn-clear certification-list"]/li/a[@class="carinfo"]'
        listElement = root.xpath(listClass)
        modelInfo = ''
        #判断车型列表是否有数据 code begin
        if len(listElement) > 0:
            for aElement in listElement:
                
                detailUrl = aElement.get('href')
                detailUrl = 'https://%s%s' % (self.host, detailUrl)
                model = aElement.find('div/h3').text
                infos = aElement.find('div/div').text
                infos = infos.split('／')
                if len(infos) < 3:
                    continue
                mileage = infos[0]
                carDj = infos[1]
                carCity = infos[2]
                price = aElement.find('div').find('div/em/b').text
                new_date = time.strftime("%y/%m/%d/%H")
                modelInfo = {'model': model, 'carDj': carDj, 'mileage':  mileage, 'city':carCity, 'price':price, 
                                  'detailUrl': detailUrl,'update_date':new_date}
                
                listModel.append(modelInfo)
        return   listModel  

    #解析分页的url
    def parseNextPageUrl(self, root):
        nextPageElement = root.xpath('//div[@id="listpagination"]/a[@class="page-item-next"]')
        if len(nextPageElement) > 0:
            pageUrl = nextPageElement[0].get('href')
            pageUrl = 'https://%s%s' % (self.host, pageUrl)
            return pageUrl
        return ''
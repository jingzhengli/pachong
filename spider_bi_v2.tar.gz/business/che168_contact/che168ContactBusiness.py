#-*-coding:utf-8-*-
import time
import re
import pandas as pd

class Che168ContactBusiness(object):

    def __init__(self):
        self.host = 'www.che168.com'

    #获取车辆列表信息
    def parseHtml(self, root):
        listModel = []
        listClass = '//div[@class="list-photo"]/ul[@class="fn-clear certification-list"]/li/a[@class="carinfo"]'
        listElement = root.xpath(listClass)
        modelInfo = ''
        #判断车型列表是否有数据 code begin
        if len(listElement) > 0:
            for aElement in listElement:
                
                detailUrl = aElement.get('href')
                detailUrl = 'https://%s%s' % (self.host, detailUrl)
                
                modelInfo = {'detailUrl': detailUrl}
                
                listModel.append(modelInfo)
        return   listModel  

    #获取车辆列表信息
    def parseContact(self, root,city,url,tel_set):
        people = ''
        sail = ''
        tel = ''
        address = ''
        d_append = pd.DataFrame()
        listClass = '//div[@class="car-warp content fn-clear"]/div[@class="car-info"]/div[@class="car-address"]'
        listElement = root.xpath(listClass)
        
        if(len(listElement) != 0):
            people = listElement[0].xpath('string(.)')
            people = re.findall('(.*?)发布时间',people)[0]
        else:
            print('parse people fail')
        listClass = '//div[@class="bargaining bargaining-dealer "]/div[@class="telephone"]'
        telElement = root.xpath(listClass)
        if(len(telElement) != 0):
             tel = telElement[0].xpath('string(.)')
             if(len(tel)>=13):
                 tel= tel[-13:]
        else:
            print('parse tel fail')
        '''
        listClass = '//div[@class="tab-content"]/div[@class="tab-content-item current"]/div[@class="store-info fn-clear"]'
        telElement = root.xpath(listClass)
        if(len(telElement) != 0):
        
            listClass = 'div[@class="store-info-left"]/p[class="title"]/a'
            infoElement = telElement[0].xpath(listClass)
            if(len(infoElement) != 0):
                sail = infoElement[0].text
            listClass = 'div[@class="store-info-right"]/ul/li/span'
            addElement = telElement[0].xpath(listClass)
            if(len(addElement) != 0):
                tel = addElement[0].text
                address = addElement[1].text
        '''
        if(tel in tel_set):
            print('%s is exist',tel)
            return d_append
        tel_set.add(tel)
        print('城市',city,'车商',people,'联系方式',tel,'车商网址',url)
        d_append = pd.DataFrame([{'城市':city,'车商':people,'联系方式':tel,'车商网址':url}])
        return d_append
    #解析分页的url
    def parseNextPageUrl(self, root):
        nextPageElement = root.xpath('//div[@id="listpagination"]/a[@class="page-item-next"]')
        if len(nextPageElement) > 0:
            pageUrl = nextPageElement[0].get('href')
            pageUrl = 'https://%s%s' % (self.host, pageUrl)
            return pageUrl
        return ''
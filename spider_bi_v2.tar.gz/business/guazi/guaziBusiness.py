#-*-coding:utf-8-*-
import pandas as pd
import time
class GuaziBusiness(object):

    def __init__(self):
        self.host = 'www.guazi.com'
         
    #获取车辆列表信息
    def parseModelInfo(self, root, guazi_data):
        listModel = []
        isEscape = False
        escapeCnt = 0
        try:
            modelClass = '//div[@class="list-wrap js-post"]/ul[@class="carlist clearfix js-top"]/li'
            liElement = root.xpath(modelClass)
            for li in liElement:
                aElement = li.find('a')
                detailUrl = aElement.get('href')
                model = aElement.find('h2').text
                ymList = aElement.xpath('div/text()')
                year = ymList[0]
                mileage = ymList[1]
                city = ''
                if len(ymList) > 1:
                    city = ymList[2]
                price = li.xpath('a/div[@class="t-price"]/p')[0].text
                detailUrl = 'https://%s%s' % (self.host, detailUrl)
                isExist = self.find_exist(city,year,mileage,detailUrl,len(self.host)+8,price,guazi_data)
                if(isExist==True):
                    escapeCnt = escapeCnt+1
                    print('escapeCnt',escapeCnt)
                    continue
                new_date = time.strftime("%y/%m/%d/%H")
                listModel.append({'model': model, 'carDj': year, 'mileage':  mileage, 'city':city, 'price':price, 
                                  'detailUrl': detailUrl,'update_date':new_date})
        except Exception as e:
            print(e)
        if(escapeCnt == 40):
            isEscape = True
        return listModel,isEscape

    #解析分页的url
    def pageHref(self, root):
        pageClass = '//div[@class="pageBox"]/ul/li/a[@class="next"]'
        nextEmlemnt = root.xpath(pageClass)
        if len(nextEmlemnt) == 0:
            return ''
        pageUrl = nextEmlemnt[0].get('href')
        return 'https://%s%s' % (self.host, pageUrl)
    
    def find_exist(self,city,year,mileage,url,headlen,price,guazi_data):
        isExist = False
        
        exist_price = 0
        select_data = guazi_data[guazi_data['city']==city ]
        select_data = select_data[select_data['carDj']==year]
        select_data = select_data[select_data['mileage'] == mileage]
        #city_group= guazi_data.groupby(['carDj','city'])
        #city_dict=dict(list(city_group))
        #car_group = city_dict.get((year,city),[])
        line_index =list(select_data.index)
        car_len = len(select_data)
        if(car_len == 0):
            return False
        url = url[headlen:]
        url = url.split('#')[0] 
        #car_group.index=range(car_len)
        for i in range(car_len):
            save_url=select_data.iloc[i,2][headlen:] # detail_url
            save_url=save_url.split('#')[0]
           
            if(save_url == url):
                isExist = True
                exist_price = select_data.iloc[i,5]#price
                if(abs(float(str(exist_price)) -float(price))>0.001):
                    if(pd.isnull(select_data.iloc[i,7])):
                        if(pd.isnull(select_data.iloc[i,6])):
                            price_list = str(exist_price) +':NULL,'+str(price)+':'+ time.strftime("%y/%m/%d/%H")
                        else:
                            price_list = str(exist_price) +':'+str(select_data.iloc[i,6]) +',' +str(price)+':'+ time.strftime("%y/%m/%d/%H")
                    else:    
                        price_list = select_data.iloc[i,7]+','+str(price)+':'+ time.strftime("%y/%m/%d/%H") 
                    new_date = time.strftime("%y/%m/%d/%H")
                    guazi_data.ix[line_index[i],'update_date'] = new_date
                    guazi_data.ix[line_index[i],'price_list'] = price_list
                    #insert into ori csv
                    break
           
        return  isExist
        
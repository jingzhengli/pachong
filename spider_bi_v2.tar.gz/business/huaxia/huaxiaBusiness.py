#-*-coding:utf-8-*-
import pandas as pd
import time
import lxml.html as HTML
from lib.grabHtmlBySelenium import GetHtml
import numpy as np
class HuaxiaBusiness(object):

    def __init__(self):
        self.host = 'http://www.hx2car.com'
        self.vip =  'http://vip.hx2car.com'
        self.driver = 1
        self.dir = 'output-data/huaxia'
        self.isSave = True
        self.doneFileName = 'done.txt'
        self.flagFileName = 'flag.txt'
        self.url = 'http://www.hx2car.com/quanguo/soa5'
        
        #referer = 'https://www.che168.com/china/'
        self.referer = 'http://www.hx2car.com'
        self.isSave = False
        self.headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'accept-language': "zh-CN,zh;q=0.8",
            #'Accept-Encoding': 'gzip, deflate, br',
            'cache-control': "no-cache", 
            'Connection': 'keep-alive',
            'Host': 'http://www.hx2car.com',
            'Referer': self.referer,
            'Upgrade-Insecure-Requests': '1'
        }

    #获取车辆列表信息
    def parseHtml(self, root,url,city,modelFilePath):
        
        stringInfo = ''
        city = ''
        sail =''
        people = ''
        contact = ''
        address = ''
        d_append = pd.DataFrame()
        '''
        carClass='//div[@class="cardetail"]/div[@class="cardetailR"]/div[@class="cardetailR_Host relative"]'
        info = root.xpath(carClass)
        if(len(info)==0 ):
            carClass='//div[@class="cardetail"]/div[@class="cardetailR"]/div[@class="cardetailR_Host"]'
            info = root.xpath(carClass)               
        sail_elment = info[0].xpath('div[@class="info_per"]/div[@class="name"]')
        if(len(sail_elment)!=0):
            sail = sail_elment[0].text
            if(sail in s1):
                return 
        people_elment = info[0].xpath('div[@class="intro"]/div/span/a')  
        if(len(people_elment)!=0):
            people = people_elment[0].text
        

        
        shop_elment = info[0].xpath('div[@class="intro"]/a[@class="intro_shop"]')  
        url = shop_elment[0].get('href')
        url = url.strip(' ')
        if(url[-1]!='/'):
            url = url+'/'
        url = url + 'business.html'
        
        sc = GetHtml(self.driver, self.headers)
        try:
            html = sc.getHtml(url)
            sc.clear()
            root = HTML.fromstring(html)
        '''   
        try: 
            sailClass='//div[@class="bg"]/div[@class="content"]/div[@class="info"]/div[@class="mdinfo"]/p'
            info = root.xpath(sailClass)
            if(len(info) == 0):
                return d_append
            sail = info[0].text
            if(type(sail)!=str):
               sail ='' 
            carClass='//div[@class="bg"]/div[@class="content"]/div[@class="info"]/ul[@class="personinfo"]/li'
            info = root.xpath(carClass)
            for i in range(len(info)):
                if(i==0):
                    people = info[i].text
                if(i==1):
                    contact = info[i].text
                if(i>=2):    
                    address = address +info[i].text
        except Exception as e:
            print(e)
                   
                           
            
        stringInfo = city + ','+sail+','+people+','+contact + ','+address+','+url+'\n'


        print(stringInfo)
        with open(modelFilePath, 'a') as f:
            f.write(stringInfo)
        d_append = pd.DataFrame([{'城市':city,'车商':sail,'联系人':people,'联系方式':contact,'联系地址':address,'车商网址':url}])
        
        return d_append
        

    #解析分页的url
    def pageHref(self, root):
        pageClass = '//div[@class="page"]/ul/a[@class="num"]'
        nextEmlemnt = root.xpath(pageClass)
        if len(nextEmlemnt) == 0:
            return ''
        pageUrl = nextEmlemnt[1].get('href')
        if(nextEmlemnt[1].text!='下一页'):
            return ''
        if(type(pageUrl) != str or pageUrl == ''):
            return ''
        return '%s%s' % (self.host, pageUrl)

        
#-*-coding:utf-8-*-

import sys
from lib.application import Application

argv = sys.argv
app = Application(argv)
app.run()
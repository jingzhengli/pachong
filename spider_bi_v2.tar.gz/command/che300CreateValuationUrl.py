#-*- coding: UTF-8 -*-

from lib.commandAbstract import CommandAbstract
from lib.grabHtmlBySelenium import GetHtml
from business.che300.che300Business import Che300Business
import os
import pandas as pd

class Che300CreateValuationUrl(CommandAbstract):

    def configure(self):
        self.name = 'create:che300:valuation:url'
        self.description = '生成车300估价的页面url'
        self.title = 'che300'
        self.setArguments('fileName', '需要用车置宝的上拍数据[csv文件格式]生成符合够调用车300估价的接口')
        
    def run(self):
        fileName = self.getArguments('fileName')
        if fileName == '':
            print('请输入竞拍数据的csv文件名')
            exit()

        che300Dir = 'input-data/%s' % (self.title)
        if os.path.exists(che300Dir) == False:
            os.mkdir(che300Dir)

        cities = pd.read_csv('resources/czbPipeiChe300City.csv', encoding='utf-8')
        
        try:
            modelInfo = pd.read_csv('resources/czbPipeiChe300Model.csv', encoding='utf-8')
        except Exception as e:
            modelInfo = pd.read_csv('resources/czbPipeiChe300Model.csv', encoding='gbk')

        auctionFile = 'resources/auction/%s.csv' % fileName
        try:
            auctionInfo = pd.read_csv(auctionFile, encoding='utf-8')
        except Exception as e:
            auctionInfo = pd.read_csv(auctionFile, encoding='gbk')
        auctionBrands = auctionInfo['carbrand']
        auctionSerieses = auctionInfo['carmodel']
        auctionModels = auctionInfo['cartype']
        auctionModelIds = auctionInfo['cartypeid']
        auctionCities = auctionInfo['carregion']
        auctionMileages = auctionInfo['mileage']
        auctionDjs = auctionInfo['dj']
        count = 0
        listPipeiModel = []
        count = 0
        modelcnt = 0
        citycnt = 0
        url = ''
        for i, modelId in enumerate(auctionModelIds):
            try:
                city = auctionCities[i]
                dj = auctionDjs[i].replace(' 0:00', '')
                listDj = dj.split('-')
                if int(listDj[0]) < 1990 or int(listDj[1]) > 12:
                    print('上牌日期有问题:%s' % (dj))
                    continue
                dj = '%s-%s' % (listDj[0], listDj[1])
                mileage = float(auctionMileages[i]) / 10000
                if mileage <= 0.1:
                    mileage = 0.1
                che300ModelId = self.getChe300Model(modelInfo, modelId)
                che300CityInfo = self.getChe300City(cities, city)
                if(che300ModelId > 0):
                    modelcnt = modelcnt+1
                    
                if len(che300CityInfo) > 0 and che300ModelId > 0:
                    citycnt = citycnt + 1
                    listPipeiModel.append(modelId)
                    url_ = 'https://www.che300.com/pinggu/v%sc%sm%sr%sg%0.1f?click=homepage' % (che300CityInfo[0],che300CityInfo[1],che300ModelId,dj,mileage)
                    if url != '':
                        url = '%s\n%s' % (url, url_)
                    else:
                        url = url_
                         
            except Exception as e:
                print(e)
        
        with open('output-data/che300/valuationUrl.txt', 'w') as f:
            f.write(url)

        listNotPipeiModel = []
        for i, modelId in enumerate(auctionModelIds):
            if str(modelId) == 'nan':
                continue
            if int(modelId) not in listPipeiModel:
                lubanModel = '%s %s' % (auctionSerieses[i], auctionModels[i])
                listNotPipeiModel.append({'lubanModel':lubanModel, 'lubanModelId': auctionModelIds[i], 'che300Model': '', 'che300ModelId': ''})
        pddata = pd.DataFrame(listNotPipeiModel)
        pddata.to_csv("output-data/che300/listNotPipeiModel.csv", index=False)

        #che300CityInfo = self.getChe300City(cities, city)
        #print(che300CityInfo)

    def getChe300City(self, cities, city):
        czbCities = cities['czbCity']
        che300Cities = cities['che300CityId']
        che300Provs = cities['che300ProvId']
        for i,czbCity in enumerate(czbCities):
            if czbCity == city:
                return [che300Provs[i], che300Cities[i]]
        return []

    def getChe300Model(self, modelInfo, modelId):
        lubanModelIds = modelInfo['lb_moduleId']
        che300ModelIds = modelInfo['che300_model_id']
        for i, lubanModelId in enumerate(lubanModelIds):
            if int(lubanModelId) == int(modelId):
                return che300ModelIds[i]
        return 0
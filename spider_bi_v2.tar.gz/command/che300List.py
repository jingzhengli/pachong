#-*-coding:utf-8-*-

from lib.commandAbstract import CommandAbstract
from lib.grabHtmlBySelenium import GetHtml
from business.che300.che300Business import Che300Business
import sys, os, random, time, json
import lxml.html as HTML
import pandas as pd
class che300List(CommandAbstract):

    def __init__(self):
        CommandAbstract.__init__(self)
        self.driver = 0
        self.fileName = ''
        self.tab = '    '
        self.rootDir = 'output-data/che300'
        self.flagFile = '%s/flag.txt' % (self.rootDir)
    
        self.host = 'www.che300.com'
        self.referer = 'http://www.baidu.com/'
        self.url = 'https://www.che300.com/buycar/?city=0&p='
        self.title = 'che300'
        self.ipProxy = False
        self.logdir = 'log/che300'
        self.headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'accept-language': "zh-CN,zh;q=0.8",
            'cache-control': "no-cache", 
            'Connection': 'keep-alive',
            'Host': self.host,
            'Referer': self.referer,
            'Upgrade-Insecure-Requests': '1'
        }
    
   

    def configure(self):
        self.name = 'che300:list'
        self.description = '抓车型数据'
    def get_data(self):
        datadir = '%s/spider_data_csv' %(self.rootDir)
        listFile = os.listdir(datadir)
        data_all = pd.DataFrame()
        for f in listFile:
            
            if f.find('csv')>-1:
                csv_data = '%s/%s'%(datadir,f)
                data_temp = pd.read_csv(csv_data,encoding='utf-8')
                data_all = pd.concat([data_all,data_temp])
        return data_all 
       
    def run(self):
        
        self.self_data = self.get_data()
        
        url = self.url
        self.titlePath = 'output-data/%s' % (self.title)
        if os.path.exists(self.titlePath) == False:
            os.mkdir(self.titlePath)
        doneFile = '%s/done.txt' % (self.titlePath)
        if os.path.exists(doneFile) == True:
            print('done')
            return

        self.gb = Che300Business()
        nowTime = time.strftime("%m%d", time.localtime())
        csvPath = '%s/%s/%s%s%s' % (self.rootDir,'spider_data_csv','che300_', nowTime,'.csv')
        if(os.path.exists(csvPath) == True):
            data_csv = pd.read_csv(csvPath,encoding='utf-8')
        else:
            data_csv = pd.DataFrame()
        self.flagFile = '%s/flag.txt' % (self.titlePath)
        if os.path.exists(self.flagFile) == True:
            with open(self.flagFile, 'r') as f:
                flagUrl = f.read()
                flagUrl = flagUrl.split('\n')[-2]
            sc = GetHtml(self.driver, self.headers, self.ipProxy)
            html = sc.getHtml(flagUrl)
            sc.clear()
            root = HTML.fromstring(html)
            pageUrl = self.gb.pageHref(root)
            if pageUrl == '':
                print('pageUrl is null')
                return -2
            url = pageUrl
            self.sleepInfo(url)
        res = self.che300Data(url, self.headers,data_csv)
        if res == 1:
            with open(doneFile, 'w') as f:
                f.write('done')
        print(res)

    def che300Data(self, url, headers,data_csv):
        pagecnt = 0
        dict_price = dict(zip(list(self.self_data['detailUrl']),list(self.self_data['price'])))
        
        while(url != ''):
            arrUrl = url.split('/')
            fileName = arrUrl[4]
            fileName = fileName.split('&')[-1]
            sc = GetHtml(self.driver, headers, self.ipProxy)
            try:
                html = sc.getHtml(url)
            except Exception as e:
                print(e)
                self.sleepInfo(url,150,180)
                continue
            sc.clear()
    
            root = HTML.fromstring(html)
            (listModel,changeUrl) = self.gb.parseModelInfo(root,self.self_data,dict_price)
            if len(listModel) == 0:
                logPath = 'log/%s' % (self.title)
                if os.path.exists(logPath) == False:
                    os.mkdir(logPath)
                logFile = '%s/%s.html' % (logPath, fileName)
                with open(logFile, 'w') as f:
                    f.write(html)
                if(changeUrl == True):
                    pageUrl = self.gb.pageHref(root,url) 
                else:
                    pageUrl = self.gb.pageHref(root)
            
                self.sleepInfo(pageUrl)
                self.headers['Referer'] = url
                url = pageUrl    
                continue
            #nowTime = time.strftime("%Y-%m-%d-%H", time.localtime())
            listModelNew = []
            #sc = GetHtml(self.driver, headers, self.ipProxy)
            for model_dict in listModel:
                '''
                detailUrl = model_dict['detailUrl']
                   
                try:
                    html_sub = sc.getHtml(detailUrl)
                except Exception as e:
                    print(e)
                    self.sleepInfo(url,150,180)
                    continue
                root_sub = HTML.fromstring(html_sub)               
                (lowestPrice,predictPrice) = self.gb.parsePredictPrice(root_sub)
                '''
                model_dict['lowestPrice'] = '' #lowestPrice
                model_dict['predictPrice'] ='' #predictPrice
                listModelNew.append(model_dict)
                
            #sc.clear()
            d1 =pd.DataFrame(listModelNew)
            data_csv = pd.concat([data_csv,d1])
            print('the len of data is ',len(data_csv))
            '''
            resPath = '%s/%s' % (self.titlePath, nowTime)
            
            if os.path.exists(resPath) == False:
                os.mkdir(resPath)
            resFile = '%s/%s.txt' % (resPath, fileName)
            
            lines = ''
            for model in listModelNew:
                line = ''
                for (k, v) in model.items():
                    line += k + '=' + v + ','
                if lines != '':
                    lines = '%s\n%s' % (lines, line)
                else:
                    lines = line
            with open(resFile, 'w') as f:
                f.write(lines)
            '''    
            with open(self.flagFile, 'a') as f:
                url = url + '\n'
                f.write(url)
            pagecnt = pagecnt + 1    
            if pagecnt % 10 == 0:
                nowTime = time.strftime("%m%d", time.localtime())
                csvPath = '%s/%s/%s%s%s' % (self.rootDir,'spider_data_csv','che300_', nowTime,'.csv')
                data_csv.to_csv(csvPath,  index=False)
                pagecnt = 0
            if(changeUrl == True):
                pageUrl = self.gb.pageHref(root,url) 
            else:
                pageUrl = self.gb.pageHref(root)
            
            self.sleepInfo(pageUrl)
            self.headers['Referer'] = url
            url = pageUrl
        logfile = '%s/%s'%(self.logdir,'html_last') 
        with open(logfile, 'a') as f:
            f.write(html)
        return 1
    
    def sleepInfo(self, title, start = 15, end = 50):
        st = random.randint(start, end)
        f = st / 10.0
        print('%s begin sleeping for %s seconds' %(title,f))
        time.sleep(f)





#-*- coding: UTF-8 -*-

from lib.commandAbstract import CommandAbstract
from business.che300.che300Business import Che300Business
import pandas as pd
import time, os,json
import re
class che300ValuationResultIntoCsv(CommandAbstract):

    def configure(self):
        self.name = 'che300:valuation:result:csv'
        self.description = '把车300的估价结果导入csv文件了'
        
    def run(self):
        
        fileDir = 'output-data/che300/valuation_result'
        if os.path.exists(fileDir) == False:
            print('目录 %s 不存在' % (fileDir))
            exit()
        listFiles = os.listdir(fileDir)
        try:
            modelInfo = pd.read_csv('resources/czbPipeiChe300Model.csv', encoding='utf-8')
        except Exception as e:
            modelInfo = pd.read_csv('resources/czbPipeiChe300Model.csv', encoding='gbk')

        self.che300ModelIdFromCsv = modelInfo['che300_model_id']
        self.lubanModelFromCsv = modelInfo['lb_seriesModule']
        self.lubanModelIdFromCsv = modelInfo['lb_moduleId']
        listResult = []
        d1 ={'2010-1':98,'2010-2':97,'2010-3':96,'2010-4':95,'2010-5':94,'2010-6':93,'2010-7':92,'2010-8':91,'2010-9':90,
              '2010-10':89,'2010-11':88,'2010-12':87,'2011-1':86,'2011-2':85,'2011-3':84,'2011-4':83,'2011-5':82,'2011-6':81,'2011-7':80,'2011-8':79,'2011-9':78,
              '2011-10':77,'2011-11':76,'2011-12':75,'2012-1':74,'2012-2':73,'2012-3':72,'2012-4':71,'2012-5':70,'2012-6':69,'2012-7':68,'2012-8':67,'2012-9':66,
              '2012-10':65,'2012-11':64,'2012-12':63,'2013-1':62,'2013-2':61,'2013-3':60,'2013-4':59,'2013-5':58,'2013-6':57,'2013-7':56,'2013-8':55,'2013-9':54,
              '2013-10':53,'2013-11':52,'2013-12':51,'2014-1':50,'2014-2':49,'2014-3':48,'2014-4':47,'2014-5':46,'2014-6':45,'2014-7':44,'2014-8':43,'2014-9':42,'2014-10':41,
              '2014-11':40,'2014-12':39,'2015-1':38,'2015-2':37,'2015-3':36,'2015-4':35,'2015-5':34,'2015-6':33,'2015-7':32,'2015-8':31,'2015-9':30,
              '2015-10':29,'2015-11':28,'2015-12':27,
              '2016-1':26,'2016-2':25,'2016-3':24,'2016-4':23,'2016-5':22,'2016-6':21,'2016-7':20,'2016-8':19,'2016-9':18,
              '2016-10':17,'2016-11':16,'2016-12':15,'2017-1':14,'2017-2':13,'2017-3':12,'2017-4':11,'2017-5':10,'2017-6':9,'2017-7':8,'2017-8':7,'2017-9':6,'2017-10':5,
              '2017-11':4,'2017-12':3,'2018-1':2,'2018-2':1,'2018-3':0}
        for file in listFiles:
            che300ModelId = file.split('m')[1].split('r')[0]
            age = file.split('r')[1].split('g')[0]
            
            month =d1[age] 
            mile =  re.findall('g(.*?).txt',file)[0]
            #lubanModelInfo = self.getLubanModel(che300ModelId)
            #if lubanModelInfo == {}:
                #continue
            filePath = '%s/%s' % (fileDir, file)
            with open(filePath, 'r') as f:
                valuationInfo = f.read()
            valuationInfo = json.loads(valuationInfo)
            common = '/'.join(valuationInfo['common'])
            good = '/'.join(valuationInfo['good'])
            excellent = '/'.join(valuationInfo['excellent'])
            
            dic = {
               
                'che300ModelId': che300ModelId,
                'Age':month,
                'Mile':mile,
                'common(车商收购价/个人交易价/车商零售价)': common,
                'good(车商收购价/个人交易价/车商零售价)': good,
                'excellent(车商收购价/个人交易价/车商零售价)': excellent
                }
            listResult.append(dic)
        parseResultFile = 'output-data/che300/valuation_result_che300估价.csv'
        pddata = pd.DataFrame(listResult)
        pddata.to_csv(parseResultFile, index=False)

    def getLubanModel(self, modelId):
        for i, che300ModelId in enumerate(self.che300ModelIdFromCsv):
            if int(modelId) == int(che300ModelId):
                return {'lubanModelId': self.lubanModelIdFromCsv[i], 'lubanModel': self.lubanModelFromCsv[i]}
        return {}
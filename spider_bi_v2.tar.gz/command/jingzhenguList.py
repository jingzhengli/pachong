#-*- coding: UTF-8 -*-

from lib.grabHtmlBySelenium import GetHtml
import sys, os, random, time, json
import lxml.html as HTML


#-*-coding:utf-8-*-

from lib.commandAbstract import CommandAbstract
from lib.grabHtmlBySelenium import GetHtml
from business.guazi.guaziBusiness import GuaziBusiness
import sys, os, random, time, json
import lxml.html as HTML

class JingzhenguList(CommandAbstract):

    def __init__(self):
        CommandAbstract.__init__(self)
        self.driver = 0
        self.fileName = 'o1-f1-w1'
        self.tab = '    '
        self.rootDir = 'output-data/jingzhengu'
        self.flagFile = '%s/flag.txt' % (self.rootDir)
    
        self.host = 'buycar.jingzhengu.com'
        self.referer = 'http://www.jingzhengu.com/'
        self.url = 'http://buycar.jingzhengu.com/ershouche/o1-f1-w1/'
    
        self.headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'accept-language': "zh-CN,zh;q=0.8",
            'cache-control': "no-cache", 
            'Connection': 'keep-alive',
            'Host': self.host,
            'Referer': self.referer,
            'Upgrade-Insecure-Requests': '1'
        }
    
   

    def configure(self):
        self.name = 'jingzhengu:list'
        self.description = '抓车型数据'
        
    def run(self):
        if os.path.exists(self.flagFile) == True:
            with open(self.flagFile, 'r') as f:
                flagUrl = f.read()
            if flagUrl != '':
                fileName = self.parseFileName(flagUrl)
                html = self.htmlInfo(flagUrl, fileName)
                root = HTML.fromstring(html)
                nextPageUrl = self.getNextPageUrl(root)
                if nextPageUrl != '':
                    self.sleepInfo(('%s%s' % (self.tab, nextPageUrl)))
                    self.parseHtml(nextPageUrl)
        else:
            self.parseHtml(self.url)

    








    def htmlInfo(self, url, fileName, fileFrom = 'http'):
        htmlPath = 'output-data/html/%s' % (fileName)
        if fileFrom == 'file':
            with open(htmlPath, 'r') as f:
                html = f.read()
        else:
            sc = GetHtml(self.driver, self.headers)
            html = sc.getHtml(url)
            sc.clear()

        return html
    
    def getNextPageUrl(self, root):
        nextPages = root.xpath('//p[@class="page_list"]/a[@class="downpage"]')
        for nextPage in nextPages:
            if nextPage.text == '下一页':
                nextPageUrl = nextPage.get('href')
                return 'http://%s%s' % (self.host, nextPageUrl)
        return ''
    
    def parseFileName(self,url):
        urls = url.split('/')
        if urls[-1] != '':
            fileName = urls[-1]
        else:
            fileName = urls[-2]
        return fileName
    
    def sleepInfo(self, name, start = 5, end = 20):
        st = random.randint(start, end)
        f = st/10.0
        print('%s begin sleeping, it will sleep %s' %(name, f))
        time.sleep(f)
    
    def parseHtml(self, url):
        fileName = self.parseFileName(url)
        html = self.htmlInfo(url, fileName)
        root = HTML.fromstring(html)
        liElementList = root.xpath('//div[@id="zw_xs_bd1"]/ul[@class="zw_across_list clearfix"]/li')
        modelInfo = ''
        for liElement in liElementList:
            models = liElement.xpath('div[@class="zw_ac_body"]/div[@class="zw_ac_tit"]/a/span/text()')
            if len(models) == 0:
                continue
            model = models[0]
    
            listDetail = liElement.xpath('div[@class="zw_ac_body"]/div[@class="zw_ac_bd_l clearfix"]/ul/li')
            carDj = ''
            mileage = ''
            gearBox = '--'
            city = ''
            for detail in listDetail:
                if detail.find('em').text == '上牌时间':
                    carDj = detail.find('span').text
                elif detail.find('em').text == '行驶里程':
                    mileage = detail.find('span').text
                elif detail.find('em').text == '变速箱':
                    gearBox = detail.find('span').text
                elif detail.find('em').text == '城市':
                    city = detail.find('span').text
            if carDj == '' or mileage == '' or city == '':
                continue
            prices = liElement.xpath('div[@class="zw_ac_body"]/div[@class="zw_ac_bd_r clearfix"]/span[@class="zw_ac_jia"]/text()')
            if len(prices) == 0:
                continue
            price = prices[0]
            detailUrls = liElement.xpath('div[@class="zw_ac_img"]/a[position()=2]/@href')
            detailUrl = ''
            if len(detailUrls) > 0:
                detailUrl = 'http://%s%s' % (self.host, detailUrls[0])
            if modelInfo != '':
                modelInfo = '%s\n' % (modelInfo)
            modelInfo = '%scarDj=%s%smileage=%s%scity=%s%sprice=%s%smodel=%s%sdetailUrl=%s' % (modelInfo, carDj, self.tab, mileage, self.tab, city, self.tab, price, self.tab, model, self.tab, detailUrl)
        print('%s done --------------------' % (url))
        if modelInfo == '':
            return ''
        nowTime = time.strftime("%Y-%m-%d-%H", time.localtime()) 
        fileDir = '%s/result/%s' % (self.rootDir, nowTime)
        if os.path.exists(fileDir) == False:
            os.mkdir(fileDir)
        filePath = '%s/%s' % (fileDir, fileName)
        with open(filePath, 'w') as f:
            f.write(modelInfo)
    
        with open(self.flagFile, 'w') as f:
            f.write(url)
        
        nextPageUrl = self.getNextPageUrl(root)
        if nextPageUrl != '':
            self.sleepInfo(('%s%s' % (self.tab, nextPageUrl)))
            self.parseHtml(nextPageUrl)
            print(nextPageUrl)





#-*- coding: UTF-8 -*-
from lib.commandAbstract import CommandAbstract
from lib.grabHtmlBySelenium import GetHtml
import sys, os, random, time, json
from business.che168.che168Business import Che168Business
import lxml.html as HTML
import io, gzip 

class che168List(CommandAbstract):
    
    def __init__(self):
        CommandAbstract.__init__(self)
        self.driver = 0
        self.cheDir = 'output-data/che168'
        self.isSave = True
        self.doneFileName = 'done.txt'
        self.flagFileName = 'flag.txt'
        
        self.host = 'www.che168.com'
        #referer = 'https://www.che168.com/china/'
        self.referer = 'https://www.che168.com/china/'
        self.isSave = False
        self.headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'accept-language': "zh-CN,zh;q=0.8",
            #'Accept-Encoding': 'gzip, deflate, br',
            'cache-control': "no-cache", 
            'Connection': 'keep-alive',
            'Host': self.host,
            'Referer': self.referer,
            'Upgrade-Insecure-Requests': '1'
        }
        
        
    def configure(self):
        self.name = 'che168:list'
        self.description = '抓取che168的车型数据'

    def make_dir(self):
        fileName = '%s/%s.html' % (self.cheDir, 'index')
        html = ''
        if os.path.exists(fileName):
            with open(fileName, 'r') as f:
                html = f.read()
        else: 
            sc = GetHtml(self.driver, self.headers)
            html = sc.getHtml(self.url)
            if self.save == True:
                with open(fileName, 'w') as f:
                    f.write(html)
            sc.clear()
        if html == '':
            return ''
        root = HTML.fromstring(html)
        cityClass = '//div[@class="city"]'
        cityElementList = root.xpath(cityClass)
    
        cityUrl = ''

        for city in cityElementList:
            aElementList = city.findall('a')
   
            for aElement in aElementList:

                city = aElement.text
                cityUrl = aElement.get('href')
                arrCityUrl = cityUrl.split('/')
                cityPingying = arrCityUrl[1]
                
                cityDir = '%s/%s_%s' % (self.cheDir, city, cityPingying)
                
                if os.path.exists(cityDir) == False:
                    os.mkdir(cityDir)

                price_between =['0-3','3-5','5-8','8-10','10-15','15-20','20-30','30-50','50-0']
                
                for price in price_between:
                    priceDir = '%s/%s' % (cityDir, price)
                    if os.path.exists(priceDir) == False:
                        os.mkdir(priceDir)
                        brandFilePath = '%s/index.txt' % (priceDir)
                        with open(brandFilePath, 'w') as f:
                            brandUrl = 'https://%s/%s/%s/%s' % (self.host, cityPingying,price,'#pvareaid=100509')
                            f.write(brandUrl)




    def sleepInfo(self, name, start = 5, end = 20):
        st = random.randint(start, end)
        f = st/10.0
        print('%s begin sleeping, it will sleep %s' %(name, f))
        time.sleep(f)

    def htmlInfo(self, url, fileFrom = 'http'):
        htmlPath = 'output-data/html/%s' % (url.replace('/','_'))
        if fileFrom == 'file':
            with open(htmlPath, 'r') as f:
                html = f.read()
        else:
            sc = GetHtml(self.driver, self.headers)
            html = sc.getHtml(url)
            sc.clear()
            
            if self.isSave == True:
                with open(htmlPath, 'w') as f:
                    f.write(html)
        return html

    def che168_simple(self,url,brandDirPath):
        while(url != ''):     

            sc = GetHtml(self.driver, self.headers)
            try:
                html = sc.getHtml(url)
            except Exception as e:
                print(e)
                self.sleepInfo(url,150,180)
                continue    
            sc.clear()
            root = HTML.fromstring(html)
            listModel = self.gb.parseHtml( root, brandDirPath)
            if len(listModel) == 0:
                continue
            arrUrl = url.split('/')
            if arrUrl[-1] != '':
                modelFileName = arrUrl[-1]
            else:
                modelFileName = arrUrl[-2]
            modelFilePath = '%s/%s.txt' % (brandDirPath, modelFileName)
            with open(modelFilePath, 'w') as f:
                lines = ''
                for model in listModel:
                    line = ''
                    for (k, v) in model.items():
                        line += k + '=' + v + ','
                    if lines != '':
                        lines = '%s\n%s' % (lines, line)
                    else:
                        lines = line                
                f.write(lines)
            flagFile = '%s/%s' % (brandDirPath, self.flagFileName)
            with open(flagFile, 'w') as f:
                f.write(url)                            
            #寻找是否有分页
            url = self.gb.parseNextPageUrl(root)
            
            self.sleepInfo(('    %s' % (url)))


    def che168Data(self):
        listCityDir = os.listdir(self.cheDir)
        
        for cityDir in listCityDir:
            cityDirPath = '%s/%s' % (self.cheDir, cityDir)
            if os.path.isdir(cityDirPath) == True:
                priceDirList = os.listdir(cityDirPath)
                for priceDir in priceDirList:
                    #if brandDir in ['雷丁', '康迪', '劳伦士','力帆', 'MG', '长安商用']:
                    brandDirPath = '%s/%s' % (cityDirPath, priceDir)
                    print('%s begin' % (brandDirPath))
                    #判断该城市下的这个品牌是否已抓取完成
                    doneFile = '%s/%s' % (brandDirPath, self.doneFileName)
                    if os.path.exists(doneFile) == True:
                        print('%s skiping' % (brandDirPath))
                        continue 
                    flagFile = '%s/%s' % (brandDirPath, self.flagFileName)
                    url = ''
                    if os.path.exists(flagFile) == True:
                        with open(flagFile, 'r') as f:
                            url = f.read()
                    else:
                        indexFile = '%s/index.txt' % (brandDirPath)
                        with open(indexFile, 'r') as f:
                            url = f.read()                            

                        
                    self.che168_simple(url, brandDirPath)
                    doneFile = '%s/%s' % (brandDirPath, self.doneFileName)
                    with open(doneFile, 'w') as f:
                        f.write('done')
                citydirdoneFile = '%s/%s\n' % (self.cheDir, 'city_done.txt')        
                with open(citydirdoneFile, 'a') as f:
                    f.write('%s done\n'%(cityDir)) 


    def run(self):
        self.make_dir()
        self.gb = Che168Business()
        self.che168Data()               

        print('all done')


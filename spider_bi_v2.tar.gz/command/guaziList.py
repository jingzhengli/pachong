#-*-coding:utf-8-*-

from lib.commandAbstract import CommandAbstract
from lib.grabHtmlBySelenium import GetHtml
from business.guazi.guaziBusiness import GuaziBusiness
import sys, os, random, time, json
import lxml.html as HTML
import pandas as pd

class guaziList(CommandAbstract):

    def __init__(self):
        CommandAbstract.__init__(self)
        self.driver = 0
        self.ipProxy = False
        self.index = 'https://www.guazi.com/www/buy/o1i7/#bread'
        self.host = 'www.guazi.com'
        self.referer = 'https://www.baidu.com/'
        self.title = 'guazi'
        self.headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'accept-language': "zh-CN,zh;q=0.8",
            'cache-control': "no-cache", 
            'Connection': 'keep-alive',
            'Host': 'www.guazi.com',
            'Referer': 'https://www.baidu.com/',
            'Upgrade-Insecure-Requests': '1'
        }
        
        
    def configure(self):
        self.name = 'guazi:list'
        self.description = '抓取瓜子网的车型数据'
        
    def run(self):
        url = self.index
        self.guazi_data = pd.read_csv('guazi.csv',encoding='utf-8')
        self.titlePath = 'output-data/%s' % (self.title)
        if os.path.exists(self.titlePath) == False:
            os.mkdir(self.titlePath)
        doneFile = '%s/done.txt' % (self.titlePath)
        if os.path.exists(doneFile) == True:
            print('done')
            exit()

        self.gb = GuaziBusiness()
        self.flagFile = '%s/flag.txt' % (self.titlePath)
        if os.path.exists(self.flagFile) == True:
            with open(self.flagFile, 'r') as f:
                flagUrl = f.read()
            sc = GetHtml(self.driver, self.headers, self.ipProxy)
            html = sc.getHtml(flagUrl)
            sc.clear()
            root = HTML.fromstring(html)
            pageUrl = self.gb.pageHref(root)
            if pageUrl == '':
                print('error')
                exit(-1)
            url = pageUrl
            self.sleepInfo(url)
            #url = 'https://www.guazi.com/www/buy/o5000i7/#bread'
        res = self.guaziData(url, self.headers)
        if res == 1:
            with open(doneFile, 'w') as f:
                f.write('done')
        print(res)

    def guaziData(self, url, headers):
        while(url!=''):
            arrUrl = url.split('/')
            fileName = arrUrl[5]
            
            sc = GetHtml(self.driver, headers, self.ipProxy)
            html = sc.getHtml(url)
            sc.clear()
    
            root = HTML.fromstring(html)
            (listModel,isEscape) = self.gb.parseModelInfo(root,self.guazi_data)
            if len(listModel) == 0 and isEscape == False:
                logPath = 'log/%s' % (self.title)
                if os.path.exists(logPath) == False:
                    os.mkdir(logPath)
                logFile = '%s/%s.html' % (logPath, fileName)
                with open(logFile, 'w') as f:
                    f.write(html)
                print('try other time')    
                self.sleepInfo(url,150,180)    
                return self.guaziData(url, self.headers)
            if(isEscape == False):
                nowTime = time.strftime("%Y-%m-%d-%H", time.localtime())
                
                resPath = '%s/%s' % (self.titlePath, nowTime)
                if os.path.exists(resPath) == False:
                    os.mkdir(resPath)
                resFile = '%s/%s.txt' % (resPath, fileName)
                lines = ''
                for model in listModel:
                    line = ''
                    for (k, v) in model.items():
                        line += k + '=' + v + ','
                    if lines != '':
                        lines = '%s\n%s' % (lines, line)
                    else:
                        lines = line
                with open(resFile, 'w') as f:
                    f.write(lines)
            with open(self.flagFile, 'w') as f:
                f.write(url)
                self.guazi_data.to_csv('guazi.csv',  index=False)
            pageUrl = self.gb.pageHref(root)
            self.sleepInfo(pageUrl)
            self.headers['Referer'] = url
            url = pageUrl 
        return 1
    
    def sleepInfo(self, title, start = 5, end = 20):
        st = random.randint(start, end)
        f = st / 10.0
        print('%s begin sleeping for %s seconds' %(title,f))
        time.sleep(f)




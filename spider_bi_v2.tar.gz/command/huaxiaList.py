#-*- coding: UTF-8 -*-
from lib.commandAbstract import CommandAbstract
from lib.grabHtmlBySelenium import GetHtml
import sys, os, random, time, json
from business.huaxia.huaxiaBusiness import HuaxiaBusiness
import lxml.html as HTML
import io, gzip 
import pandas as pd
import numpy as np
s1 = set()
class huaxiaList(CommandAbstract):
    
    def __init__(self):
        CommandAbstract.__init__(self)
        self.driver = 1
        self.dir = 'output-data/huaxia'
        self.logdir = 'log/huaxia'
        self.isSave = True
        self.doneFileName = 'done.txt'
        self.flagFileName = 'flag.txt'
        self.url = 'http://www.hx2car.com/quanguo/soa3'
        self.host = 'http://www.hx2car.com'
        #referer = 'https://www.che168.com/china/'
        self.referer = 'http://www.hx2car.com'
        self.isSave = False
        self.headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'accept-language': "zh-CN,zh;q=0.8",
            #'Accept-Encoding': 'gzip, deflate, br',
            'cache-control': "no-cache", 
            'Connection': 'keep-alive',
            'Host': 'http://www.hx2car.com',
            'Referer': self.referer,
            'Upgrade-Insecure-Requests': '1'
        }
        
        
    def configure(self):
        self.name = 'huaxia:list'
        self.description = '抓取华夏的车型数据'

    def make_dir(self):
        fileName = '%s/%s.txt' % (self.dir, 'index')
        html = ''
        if os.path.exists(fileName):
            with open(fileName, 'r') as f:
                url = f.read()
        else:
            url = self.url 
        sc = GetHtml(self.driver, self.headers)
        html = sc.getHtml(url)

        sc.clear()
        if html == '':
            return ''
        root = HTML.fromstring(html)
        cityClass = '//div[@class="Fenzhan"]/div[@class="newFenzhan_city"]/div[@class="newFenzhan_city_cont"]/div[@class="letter_class"]/div[@class="city_box"]/div[@class="city"]/a'
        
        cityElementList = root.xpath(cityClass)
    
        cityUrl = ''

        for city in cityElementList:
            cityUrl = city.get('href')
            cityUrl=cityUrl.replace('soa1','soa3')
            cityName = city.text
            cityDir = '%s/%s' % (self.dir, cityName)
            
            if os.path.exists(cityDir) == False:
                os.mkdir(cityDir)

            brandFilePath = '%s/index.txt' % (cityDir)
            with open(brandFilePath, 'w') as f:
                brandUrl = '%s%s' % (self.host,cityUrl)
                f.write(brandUrl)




    def sleepInfo(self, name, start = 5, end = 20):
        st = random.randint(start, end)
        f = st/10.0
        print('%s begin sleeping, it will sleep %s' %(name, f))
        time.sleep(f)

    def htmlInfo(self, url, fileFrom = 'http'):
        htmlPath = 'output-data/html/%s' % (url.replace('/','_'))
        if fileFrom == 'file':
            with open(htmlPath, 'r') as f:
                html = f.read()
        else:
            sc = GetHtml(self.driver, self.headers)
            html = sc.getHtml(url)
            sc.clear()
            
            if self.isSave == True:
                with open(htmlPath, 'w') as f:
                    f.write(html)
        return html

    def huaxia_page(self,url,dirPath,city):
        while(url != ''):     
            print(url)
            sc = GetHtml(self.driver, self.headers)
            try:
                html = sc.getHtml(url)
            except Exception as e:
                print(e)
                self.sleepInfo('first url failed'+url,150,180)
                continue    
            sc.clear()
            root = HTML.fromstring(html)
            carClass='//div[@class="cars"]/div[@class="carsL"]/div[@class="Datu_list"]'
            carList = root.xpath(carClass)
            if(len(carList) == 0):
                
                return 
            carElementList0 = carList[0]
            #carClass='div[@class="Datu_cars"]/div[@class="Datu_car carlog"]/div[@class="pic"]/a'
            carClass='div[@class="Datu_cars"]/div[@class="Datu_car carlog"]/div[@class="car_border"]/div[@class="carPrice_user"]/p[@class="owner"]/a[@class="name"]'
            
            carElementList = carElementList0.xpath(carClass)
            
            arrUrl = url.split('/')
            if arrUrl[-1] != '':
                modelFileName = arrUrl[-1]
            else:
                modelFileName = arrUrl[-2]
            modelFilePath = '%s/%s.txt' % (dirPath, modelFileName)
            dict1 = list(self.exist_data['车商网址'])
            for carElement in carElementList:
                carurl = carElement.get('href')
                url1 = carurl.strip(' ')
                if(url1[-1]!='/'):
                    url1 = url1+'/'
                url1 = url1 + 'business.html'
                #if(url1 in s1):
                if(url1 in dict1):    
                    print('%s is the same',url1)
                    continue
                if(url1.find('profile')>-1):
                    print('personal')
                    with open('%s/%s'%(self.logdir,modelFileName), 'a') as f:
                        f.write(url1)                     
                    continue
                sc = GetHtml(self.driver, self.headers)
                try:
                    html = sc.getHtml(url1)
                except Exception as e:
                    print(e)
                    self.sleepInfo('second url failed'+url1,150,180)
                    continue    
                sc.clear()
                root1 = HTML.fromstring(html)
                df1 = self.gb.parseHtml( root1,url1,city,modelFilePath)
                if(len(df1)!=0):
                    dict1.append(df1['车商网址'].iloc[0])
                    self.exist_data = pd.concat([self.exist_data,df1])
                #s1.add(url1)
                
                

            flagFile = '%s/%s' % (dirPath, self.flagFileName)
            with open(flagFile, 'w') as f:
                f.write(url)                            
            #寻找是否有分页
            url = self.gb.pageHref(root)
            
            self.sleepInfo(('next_page    %s' % (url)))
        return

    def huaxiaData(self):
        citydir = os.listdir(self.dir)
        
        for city in citydir:
            cityDirPath = '%s/%s' % (self.dir, city)
            if os.path.isdir(cityDirPath) == True:
                

                #判断该城市下的这个品牌是否已抓取完成
                doneFile = '%s/%s' % (cityDirPath, self.doneFileName)
                if os.path.exists(doneFile) == True:
                    print('%s skiping' % (cityDirPath))
                    continue 
                flagFile = '%s/%s' % (cityDirPath, self.flagFileName)
                url = ''
                if os.path.exists(flagFile) == True:
                    with open(flagFile, 'r') as f:
                        url = f.read()
                else:
                    indexFile = '%s/index.txt' % (cityDirPath)
                    with open(indexFile, 'r') as f:
                        url = f.read()                            

                    
                self.huaxia_page(url, cityDirPath, city)
                doneFile = '%s/%s' % (cityDirPath, self.doneFileName)
                with open(doneFile, 'w') as f:
                    f.write('done')                    
                self.exist_data.to_csv('data_1.csv',encoding='utf-8',index = False)      

                citydirdoneFile = '%s/%s\n' % (self.dir, 'all_done.txt')        
                with open(citydirdoneFile, 'a') as f:
                    f.write('%s done\n'%(cityDirPath)) 
                    
                    
        self.exist_data.to_csv('data_1.csv',encoding='utf-8',index = False)

    def run(self):
        self.make_dir()
        self.gb = HuaxiaBusiness()
        self.exist_data = pd.read_csv('data_1.csv',encoding='utf-8')
        self.huaxiaData()               

        print('all done')

